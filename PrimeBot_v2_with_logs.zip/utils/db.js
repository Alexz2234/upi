const fs = require('fs');
const path = require('path');
const DB_PATH = path.join(__dirname, '..', 'db', 'data.json');

function read() {
  try {
    return JSON.parse(fs.readFileSync(DB_PATH, 'utf8'));
  } catch (e) {
    const init = { upis: [], giveaways: [], orders: [], afk: {}, settings: { ownerId: null, staffRoleId: null, ownerPingWarn: false } };
    fs.writeFileSync(DB_PATH, JSON.stringify(init, null, 2));
    return init;
  }
}

function write(obj) {
  fs.writeFileSync(DB_PATH, JSON.stringify(obj, null, 2));
}

module.exports = { read, write };
