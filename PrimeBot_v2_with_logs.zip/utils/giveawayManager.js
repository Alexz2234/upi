const db = require('./db');

function enterGiveawayById(giveawayId, userId) {
  const data = db.read();
  const g = data.giveaways.find(x => String(x.id) === String(giveawayId));
  if (!g) return false;
  g.entries = g.entries || [];
  if (!g.entries.includes(userId)) {
    g.entries.push(userId);
    db.write(data);
    return true;
  }
  return false;
}

module.exports = { enterGiveawayById };
