# Prime Bot v2

A multipurpose Discord bot built using **Discord.js v14**.
Includes: UPI management, giveaways with button joins, owner/admin tools, orders, and utilities.

## Quick start

1. Copy `.env.example` to `.env` and fill values.
2. `npm install`
3. `npm run register-commands`
4. `npm start`

## Commands overview

- /add_upi, /list_upi, /remove_upi, /upi_qr
- /gstart, /glist, /gend, /geroll (users join via 🎉 button)
- /order — logs orders to db and DMs owner (if OWNER_ID set)
- Owner commands: /owneraddrole, /ownerchangerole, /ownerpingwarn, /staff_access_role, /staff_access_role_change
- Utilities: /embed, /say, /stats, /ping, /remind, /afk

## Notes
- JSON storage in `db/data.json` for testing. For production use MongoDB.
- Deploy using Railway, Render, or Replit by setting env vars and running `npm start`.
