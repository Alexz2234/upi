require('dotenv').config();
const path = require('path');
const fs = require('fs');
const { Client, Collection, GatewayIntentBits, Partials, ActionRowBuilder, ButtonBuilder, ButtonStyle, Events } = require('discord.js');
const db = require('./utils/db');
const logger = require('./utils/logger');
const giveawayManager = require('./utils/giveawayManager');

const client = new Client({ intents: [GatewayIntentBits.Guilds, GatewayIntentBits.GuildMessages, GatewayIntentBits.MessageContent, GatewayIntentBits.GuildMembers], partials: [Partials.Channel] });
client.commands = new Collection();

// load commands
function walk(dir) {
  for (const file of fs.readdirSync(dir)) {
    const fp = path.join(dir, file);
    if (fs.statSync(fp).isDirectory()) walk(fp);
    else if (file.endsWith('.js')) {
      const cmd = require(fp);
      if (cmd.data && cmd.execute) client.commands.set(cmd.data.name, cmd);
    }
  }
}
walk(path.join(__dirname, 'commands'));

client.once('ready', () => {
  logger.log('Bot is ready');
  console.log(`Logged in as ${client.user.tag}`);
  const data = db.read();
  if (!data.settings.ownerId && process.env.OWNER_ID) {
    data.settings.ownerId = process.env.OWNER_ID;
    db.write(data);
  }
  setInterval(checkGiveaways, 10_000);
});

client.on('interactionCreate', async (interaction) => {
  try {
    if (interaction.isButton()) {
      const [type, id] = interaction.customId.split(':');
      if (type === 'giveaway_join') {
        const added = giveawayManager.enterGiveawayById(id, interaction.user.id);
        if (added) await interaction.reply({ content: 'You joined the giveaway 🎉', ephemeral: true });
        else await interaction.reply({ content: 'You are already entered or giveaway not found.', ephemeral: true });
      }
      return;
    }
    if (!interaction.isChatInputCommand()) return;
    const cmd = client.commands.get(interaction.commandName);
    if (!cmd) return;
    await cmd.execute(interaction, client, db);
  } catch (e) {
    console.error('interaction error', e);
    if (interaction.replied || interaction.deferred) await interaction.followUp({ content: 'Error executing command.', ephemeral: true });
    else await interaction.reply({ content: 'Error executing command.', ephemeral: true });
  }
});

async function checkGiveaways() {
  const data = db.read();
  const now = Date.now();
  let changed = false;
  for (const g of data.giveaways.filter(x => !x.ended && x.endsAt <= now)) {
    try {
      const guild = await client.guilds.fetch(g.guildId).catch(()=>null);
      if (!guild) continue;
      const channel = await guild.channels.fetch(g.channelId).catch(()=>null);
      if (!channel) continue;
      const entries = g.entries || [];
      let winners = [];
      if (entries.length > 0) {
        const count = Math.min(g.winnerCount || 1, entries.length);
        const shuffled = entries.sort(() => 0.5 - Math.random());
        winners = shuffled.slice(0, count);
      }
      const text = winners.length ? `Winner(s): ${winners.map(w=>`<@${w}>`).join(', ')}` : 'No entries.';
      await channel.send({ content: `🎉 **Giveaway ended** — ${text}` }).catch(()=>{});
      g.ended = true;
      changed = true;
    } catch (e) { console.error('giveaway end error', e); }
  }
  if (changed) db.write(data);
}

client.login(process.env.DISCORD_TOKEN);
