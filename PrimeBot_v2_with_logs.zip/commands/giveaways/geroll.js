const { SlashCommandBuilder } = require('discord.js');
module.exports = {
  data: new SlashCommandBuilder().setName('geroll').setDescription('Reroll giveaway winners').addStringOption(o=>o.setName('id').setDescription('Giveaway id').setRequired(true)),
  async execute(interaction, client, db) {
    const id = interaction.options.getString('id');
    const data = db.read();
    const g = data.giveaways.find(x=>String(x.id)===String(id) && x.guildId===interaction.guildId);
    if (!g) return interaction.reply({ content: 'Giveaway not found.', ephemeral: true });
    const entries = g.entries || [];
    if (!entries.length) return interaction.reply({ content: 'No entries to pick from.', ephemeral: true });
    const count = Math.min(g.winnerCount || 1, entries.length);
    const shuffled = entries.sort(() => 0.5 - Math.random());
    const winners = shuffled.slice(0, count);
    await interaction.reply({ content: `New winner(s): ${winners.map(w=>`<@${w}>`).join(', ')}` });
  }
};
