const { SlashCommandBuilder } = require('discord.js');
module.exports = {
  data: new SlashCommandBuilder().setName('gend').setDescription('End a giveaway now').addStringOption(o=>o.setName('id').setDescription('Giveaway id').setRequired(true)),
  async execute(interaction, client, db) {
    const id = interaction.options.getString('id');
    const data = db.read();
    const g = data.giveaways.find(x=>String(x.id)===String(id) && x.guildId===interaction.guildId);
    if (!g) return interaction.reply({ content: 'Giveaway not found.', ephemeral: true });
    g.endsAt = Date.now() - 1000;
    db.write(data);
    await interaction.reply({ content: 'Giveaway will end shortly.', ephemeral: true });
  }
};
