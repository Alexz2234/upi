const { SlashCommandBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
module.exports = {
  data: new SlashCommandBuilder()
    .setName('gstart')
    .setDescription('Start a giveaway (seconds)')
    .addIntegerOption(o=>o.setName('duration').setDescription('Duration in seconds').setRequired(true))
    .addIntegerOption(o=>o.setName('winners').setDescription('Number of winners').setRequired(false)),
  async execute(interaction, client, db) {
    const logger = require('../../utils/logger');
    const duration = interaction.options.getInteger('duration');
    const winners = interaction.options.getInteger('winners') || 1;
    const data = db.read();
    const g = { id: Date.now(), guildId: interaction.guildId, channelId: interaction.channelId, messageId: null, createdBy: interaction.user.id, endsAt: Date.now() + duration*1000, winnerCount: winners, entries: [], ended: false };
    data.giveaways.push(g);
    db.write(data);

    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId(`giveaway_join:${g.id}`).setLabel('🎉 Join').setStyle(ButtonStyle.Primary)
    );
    const msg = await interaction.reply({ content: `🎉 **Giveaway started!** ID: ${g.id} — ends <t:${Math.floor(g.endsAt/1000)}:R>`, components: [row], fetchReply: true });
    // store message id
    const d = db.read();
    logger.log('Giveaway started by ' + interaction.user.tag);
    const gg = d.giveaways.find(x=>String(x.id)===String(g.id));
    if (gg) { gg.messageId = msg.id; db.write(d); }
  }
};
