const { SlashCommandBuilder } = require('discord.js');
module.exports = {
  data: new SlashCommandBuilder().setName('glist').setDescription('List active giveaways'),
  async execute(interaction, client, db) {
    const data = db.read();
    const list = data.giveaways.filter(g=>!g.ended && g.guildId===interaction.guildId);
    if (!list.length) return interaction.reply({ content: 'No active giveaways in this server.', ephemeral: true });
    const lines = list.map(g=>`ID: ${g.id} — ends <t:${Math.floor(g.endsAt/1000)}:R> — entries: ${g.entries ? g.entries.length : 0}`).join('\n');
    await interaction.reply({ content: lines, ephemeral: true });
  }
};
