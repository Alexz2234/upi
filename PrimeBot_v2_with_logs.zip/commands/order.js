const { SlashCommandBuilder } = require('discord.js');
module.exports = {
  data: new SlashCommandBuilder()
    .setName('order')
    .setDescription('Place an order (logs to db and notifies owner)')
    .addStringOption(o=>o.setName('item').setDescription('Item to order').setRequired(true))
    .addStringOption(o=>o.setName('notes').setDescription('Notes')),
  async execute(interaction, client, db) {
    const logger = require('../../utils/logger');
    const item = interaction.options.getString('item');
    const notes = interaction.options.getString('notes') || '';
    const data = db.read();
    const order = { id: Date.now(), user: interaction.user.id, item, notes, createdAt: Date.now() };
    data.orders.push(order);
    logger.log('Order placed: ' + order.id + ' by ' + interaction.user.tag);
    db.write(data);
    await interaction.reply({ content: `Order placed (ID: ${order.id}).`, ephemeral: true });
    // DM owner if present
    try {
      const ownerId = data.settings.ownerId || process.env.OWNER_ID;
      if (ownerId) {
        const owner = await client.users.fetch(ownerId).catch(()=>null);
        if (owner) owner.send(`New order #${order.id}\nUser: ${interaction.user.tag}\nItem: ${item}\nNotes: ${notes}`).catch(()=>{});
      }
    } catch(e){}
  }
};
