const { SlashCommandBuilder } = require('discord.js');
module.exports = {
  data: new SlashCommandBuilder().setName('afk').setDescription('Set an AFK message').addStringOption(o=>o.setName('reason').setDescription('Reason').setRequired(false)),
  async execute(interaction, client, db) {
    const reason = interaction.options.getString('reason') || 'AFK';
    const data = db.read();
    data.afk[interaction.user.id] = { reason, at: Date.now() };
    db.write(data);
    await interaction.reply({ content: `AFK set: ${reason}`, ephemeral: true });
  }
};
