const { SlashCommandBuilder } = require('discord.js');
module.exports = {
  data: new SlashCommandBuilder().setName('list_upi').setDescription('List UPI IDs'),
  async execute(interaction, client, db) {
    const data = db.read();
    if (!data.upis.length) return interaction.reply({ content: 'No UPI IDs stored.', ephemeral: true });
    const lines = data.upis.map((u, i) => `${i+1}. **${u.name}** — \`${u.id}\``).join('\n');
    await interaction.reply({ content: `Stored UPI IDs:\n${lines}`, ephemeral: true });
  }
};
