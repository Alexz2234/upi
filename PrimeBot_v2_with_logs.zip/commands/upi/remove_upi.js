const { SlashCommandBuilder } = require('discord.js');
module.exports = {
  data: new SlashCommandBuilder()
    .setName('remove_upi')
    .setDescription('Remove a UPI ID')
    .addStringOption(o => o.setName('upi_id').setDescription('UPI id to remove').setRequired(true)),
  async execute(interaction, client, db) {
    const id = interaction.options.getString('upi_id');
    const data = db.read();
    const before = data.upis.length;
    data.upis = data.upis.filter(u => u.id !== id);
    db.write(data);
    await interaction.reply({ content: `Removed ${before - data.upis.length} entries.`, ephemeral: true });
  }
};
