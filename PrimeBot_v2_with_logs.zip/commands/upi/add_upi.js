const { SlashCommandBuilder } = require('discord.js');
module.exports = {
  data: new SlashCommandBuilder()
    .setName('add_upi')
    .setDescription('Add a UPI ID')
    .addStringOption(o => o.setName('upi_id').setDescription('UPI id').setRequired(true))
    .addStringOption(o => o.setName('name').setDescription('Name for this UPI').setRequired(true)),
  async execute(interaction, client, db) {
    const upi = interaction.options.getString('upi_id');
    const name = interaction.options.getString('name');
    const data = db.read();
    data.upis.push({ id: upi, name, addedBy: interaction.user.id, addedAt: Date.now() });
    db.write(data);
    await interaction.reply({ content: `Added UPI \`${upi}\` as **${name}**.`, ephemeral: true });
  }
};
