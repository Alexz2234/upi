const { SlashCommandBuilder } = require('discord.js');
const QRCode = require('qrcode');
module.exports = {
  data: new SlashCommandBuilder()
    .setName('upi_qr')
    .setDescription('Generate a UPI QR (image)')
    .addStringOption(o => o.setName('upi_id').setDescription('UPI id to generate QR for').setRequired(true)),
  async execute(interaction, client, db) {
    const upi = interaction.options.getString('upi_id');
    const upiUrl = `upi://pay?pa=${encodeURIComponent(upi)}&pn=${encodeURIComponent('Payment')}`;
    try {
      const buffer = await QRCode.toBuffer(upiUrl);
      await interaction.reply({ files: [{ attachment: buffer, name: 'upi.png' }] });
    } catch (e) {
      console.error(e);
      await interaction.reply({ content: 'Failed to generate QR.', ephemeral: true });
    }
  }
};
