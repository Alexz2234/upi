const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
module.exports = {
  data: new SlashCommandBuilder().setName('stats').setDescription('Show bot stats (owner only)'),
  async execute(interaction, client) {
    const data = require('../../utils/db').read();
    if (interaction.user.id !== String(data.settings.ownerId)) return interaction.reply({ content: 'Owner only.', ephemeral: true });
    const emb = new EmbedBuilder()
      .setTitle('Prime Bot Stats')
      .addFields([
        { name: 'Uptime', value: `${process.uptime().toFixed(0)}s`, inline: true },
        { name: 'Guilds', value: `${client.guilds.cache.size}`, inline: true }
      ])
      .setTimestamp();
    await interaction.reply({ embeds: [emb] });
  }
};
