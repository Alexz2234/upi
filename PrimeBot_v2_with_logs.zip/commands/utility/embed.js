const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
module.exports = {
  data: new SlashCommandBuilder()
    .setName('embed')
    .setDescription('Create an embed (owner only)')
    .addStringOption(o=>o.setName('title').setDescription('Title').setRequired(true))
    .addStringOption(o=>o.setName('description').setDescription('Description').setRequired(true)),
  async execute(interaction, client, db) {
    const data = db.read();
    if (interaction.user.id !== String(data.settings.ownerId)) return interaction.reply({ content: 'Owner only.', ephemeral: true });
    const title = interaction.options.getString('title');
    const desc = interaction.options.getString('description');
    const emb = new EmbedBuilder().setTitle(title).setDescription(desc).setTimestamp();
    await interaction.reply({ embeds: [emb] });
  }
};
