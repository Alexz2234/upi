const { SlashCommandBuilder } = require('discord.js');
module.exports = {
  data: new SlashCommandBuilder().setName('remind').setDescription('Set a reminder (seconds)').addIntegerOption(o=>o.setName('seconds').setDescription('Seconds until reminder').setRequired(true)).addStringOption(o=>o.setName('note').setDescription('Reminder note')),
  async execute(interaction) {
    const seconds = interaction.options.getInteger('seconds');
    const note = interaction.options.getString('note') || 'Reminder!';
    await interaction.reply({ content: `I'll remind you in ${seconds}s`, ephemeral: true });
    setTimeout(() => {
      interaction.user.send(`⏰ Reminder: ${note}`).catch(()=>{});
    }, seconds*1000);
  }
};
