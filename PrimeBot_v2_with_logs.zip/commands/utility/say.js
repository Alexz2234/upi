const { SlashCommandBuilder } = require('discord.js');
module.exports = {
  data: new SlashCommandBuilder().setName('say').setDescription('Make the bot say something (owner only)').addStringOption(o=>o.setName('text').setDescription('Text').setRequired(true)),
  async execute(interaction) {
    const data = require('../../utils/db').read();
    if (interaction.user.id !== String(data.settings.ownerId)) return interaction.reply({ content: 'Owner only.', ephemeral: true });
    const text = interaction.options.getString('text');
    await interaction.reply({ content: text });
  }
};
