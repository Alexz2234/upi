const { SlashCommandBuilder } = require('discord.js');
module.exports = {
  data: new SlashCommandBuilder().setName('ownerpingwarn').setDescription('Toggle owner ping warnings (owner only)'),
  async execute(interaction, client, db) {
    const data = db.read();
    if (interaction.user.id !== String(data.settings.ownerId)) return interaction.reply({ content: 'Owner only.', ephemeral: true });
    data.settings.ownerPingWarn = !data.settings.ownerPingWarn;
    db.write(data);
    await interaction.reply({ content: `ownerPingWarn set to ${data.settings.ownerPingWarn}`, ephemeral: true });
  }
};
