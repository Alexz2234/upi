const { SlashCommandBuilder } = require('discord.js');
module.exports = {
  data: new SlashCommandBuilder().setName('ownerchangerole').setDescription('Change owner/staff role (owner only)').addRoleOption(o=>o.setName('role').setDescription('New staff role').setRequired(true)),
  async execute(interaction, client, db) {
    const logger = require('../../utils/logger');
    const data = db.read();
    if (interaction.user.id !== String(data.settings.ownerId)) return interaction.reply({ content: 'Owner only.', ephemeral: true });
    const role = interaction.options.getRole('role');
    data.settings.staffRoleId = role.id;
    logger.log('Staff role changed to ' + role.name + ' by ' + interaction.user.tag);
    db.write(data);
    await interaction.reply({ content: `Staff role changed to ${role.name}`, ephemeral: true });
  }
};
