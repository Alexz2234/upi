const { SlashCommandBuilder } = require('discord.js');
module.exports = {
  data: new SlashCommandBuilder().setName('staff_access_role').setDescription('Show current staff role'),
  async execute(interaction, client, db) {
    const data = db.read();
    const id = data.settings.staffRoleId;
    if (!id) return interaction.reply({ content: 'No staff role set.', ephemeral: true });
    const role = interaction.guild.roles.cache.get(id);
    await interaction.reply({ content: `Staff role: ${role ? role.name : id}`, ephemeral: true });
  }
};
