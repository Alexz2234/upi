const { SlashCommandBuilder } = require('discord.js');
module.exports = {
  data: new SlashCommandBuilder().setName('staff_access_role_change').setDescription('Set staff role (owner only)').addRoleOption(o=>o.setName('role').setDescription('Role to set').setRequired(true)),
  async execute(interaction, client, db) {
    const data = db.read();
    if (interaction.user.id !== String(data.settings.ownerId)) return interaction.reply({ content: 'Owner only.', ephemeral: true });
    const role = interaction.options.getRole('role');
    data.settings.staffRoleId = role.id;
    db.write(data);
    await interaction.reply({ content: `Staff role updated to ${role.name}`, ephemeral: true });
  }
};
