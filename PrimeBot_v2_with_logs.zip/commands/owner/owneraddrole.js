const { SlashCommandBuilder } = require('discord.js');
module.exports = {
  data: new SlashCommandBuilder().setName('owneraddrole').setDescription('Add a role to a member (owner only)').addUserOption(o=>o.setName('user').setDescription('Target user').setRequired(true)).addRoleOption(o=>o.setName('role').setDescription('Role to add').setRequired(true)),
  async execute(interaction, client, db) {
    const data = db.read();
    if (interaction.user.id !== String(data.settings.ownerId)) return interaction.reply({ content: 'Owner only.', ephemeral: true });
    const user = interaction.options.getUser('user');
    const role = interaction.options.getRole('role');
    const member = await interaction.guild.members.fetch(user.id).catch(()=>null);
    if (!member) return interaction.reply({ content: 'Member not found.', ephemeral: true });
    await member.roles.add(role).catch(err=>{});
    await interaction.reply({ content: `Added role ${role.name} to ${user.tag}.`, ephemeral: true });
  }
};
